﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Fun_Foodi.Controllers
{
    [Filter.AuthorizeUser]
    public class FoodController : Controller
    {
        // GET: Food
        public ActionResult Index(string FoodItemNumber, string FoodItemType, string FoodItemCode, string FoodItemName, string Quantity, string Price)
        {
            ViewBag.FoodItemtype = FoodItemType;
            ViewBag.FoodItemname = FoodItemName;
            ViewBag.quantity = Quantity;
            ViewBag.price = Price;
            return View();
        }
    }
}