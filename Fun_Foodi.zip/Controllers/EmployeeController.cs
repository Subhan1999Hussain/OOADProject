﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Fun_Foodi.Models;
using Fun_Foodi.Manager;

namespace Fun_Foodi.Controllers
{
    [Filter.AuthorizeUser]
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult PasswordReset()
        {
            return View();
        }
        [HttpGet]
        public ActionResult NewEmployee()
        {
            ViewBag.Message = "";
            return View();
        }

        [HttpPost]
        public ActionResult NewEmployee(NewEmployeeModel Add)
        {
            NewEmployeeManager obj = new NewEmployeeManager();
            if (ModelState.IsValid)
            {
                int a = obj.NewEmployee(Add);
                if (a > 0)
                {
                    ViewBag.Message = "Data Enter Successfully" + a;
                }
                else
                {
                    ViewBag.Message = "Data Enter not Successfully";
                }
            }
            return View();
        }
        public ActionResult ViewEmployee()
        {
            NewEmployeeManager obj = new NewEmployeeManager();
            List<NewEmployeeModel> List = obj.SelectAdd();
            return View(List);

            
            
        }
        public ActionResult Salary()
        {
            return View();
        }
        [HttpGet]
        public ActionResult UpdateNewEmployee(int CstID)
        {
            //FunFoodiEntities2 PjE = new FunFoodiEntities2();
            //ViewBag.type = new SelectList(PjE.FITcategories, "TCID", "FoodTypeCategory");




            NewEmployeeManager obj = new NewEmployeeManager();

            NewEmployeeModel Add = obj.GetCust(CstID);
            if (Add == null)
            {
                ViewBag.Message = "Data not Found";
                return RedirectToAction("ViewEmployee");
            }
            else
            {
                ViewBag.Message = " ";
                return View(Add);
            }

        }
        [HttpPost]
        public ActionResult UpdateNewEmployee(NewEmployeeModel Cst)
        {
            if (ModelState.IsValid)
            {
                NewEmployeeManager obj = new NewEmployeeManager();

                bool check = obj.UpdatedCst(Cst);
                if (check)
                {
                    ViewBag.Message = "Data Update Successfully";
                    return RedirectToAction("ViewEmployee");
                }
                else
                {
                    return View();
                }
            }
            else
            {
                return View();
            }

        }
        public ActionResult DeleteCusotmer(int CstID)
        {
            NewEmployeeManager obj = new NewEmployeeManager();

            bool check = obj.DeleteCst(CstID);
            if (check)
            {
                ViewBag.Message = "Data Deleted Successfully";
            }
            else
            {
                ViewBag.Message = "Error";
            }
            return RedirectToAction("ViewNewEmployee");

        }
    }
}