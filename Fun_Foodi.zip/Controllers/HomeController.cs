﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Fun_Foodi.Models;
using Fun_Foodi.Manager;

namespace Fun_Foodi.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }








        [HttpPost]
        public ActionResult Login(LoginModel LoginMdl)
        {
            using (FunFoodiEntities2 DB = new FunFoodiEntities2())
            {

                var admin = DB.NewEmployees.Where(x => x.EmailAddress == LoginMdl.UserName && x.Password == LoginMdl.Password).FirstOrDefault();
                
                if (admin == null)
                {
                    ViewBag.Message = "Usrname or password incorret";

                    //LoginMdl.LoginErrorMessage = "Wrong Username or Password. ";
                    return RedirectToAction("Login", "Home");
                }
                else if (admin != null)
                {
                    Session["IsLogedIn"] = true;
                    return RedirectToAction("ViewFood", "Add");
                }
                else if (LoginMdl.UserName == "admin" && LoginMdl.Password == "123")
                {
                    return RedirectToAction("NewEmployee", "Employee");
                }

            }
            return View();
        }

        
            
        }
    }