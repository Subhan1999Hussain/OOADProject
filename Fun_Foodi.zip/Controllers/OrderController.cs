﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Fun_Foodi.Models;
using Fun_Foodi.Manager;

namespace Fun_Foodi.Controllers
{
    [Filter.AuthorizeUser]
    public class OrderController : Controller
    {
        // GET: Order
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult AddOrder()
        {
            FunFoodiEntities2 PjE = new FunFoodiEntities2();
            ViewBag.type = new SelectList(PjE.FITcategories, "TCID", "FoodTypeCategory");
            ViewBag.type2 = new SelectList(PjE.FINames, "NID", "FoodItemName");
            ViewBag.Message = "";
            return View();
        }
        [HttpPost]
        public ActionResult AddOrder(AddOrderModel Add)
        {
            AddOrderManager obj = new AddOrderManager();
            if (ModelState.IsValid)
            {
                int a = obj.addorder(Add);
                if (a > 0)
                {
                    ViewBag.Message = "Data Enter Successfully" + a;
                }
                else
                {
                    ViewBag.Message = "Data Enter not Successfully";
                }
            }
            return View();
        }

        [HttpGet]
        public ActionResult BuyingProduct()
        {
            ViewBag.Message = "";
            return View();
        }
        [HttpPost]
        public ActionResult BuyingProduct(BuyingProductModel Add)
        {
            BuyingProductManager obj = new BuyingProductManager();
            if (ModelState.IsValid)
            {
                int a = obj.BuyPro(Add);
                if (a > 0)
                {
                    ViewBag.Message = "Data Enter Successfully" + a;
                }
                else
                {
                    ViewBag.Message = "Data Enter not Successfully";
                }
            }
            return View();
        }

        
        public ActionResult ViewOrder()
        {
            AddOrderManager obj = new AddOrderManager();
            List<AddOrderModel> List = obj.SelectAdd();
            return View(List);
        }
        public ActionResult ViewBuyingProduct()
        {
            BuyingProductManager obj = new BuyingProductManager();
            List<BuyingProductModel> List = obj.SelectAdd();
            return View(List);
        }

    }
}