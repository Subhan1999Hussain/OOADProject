﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Fun_Foodi.Models;
using Fun_Foodi.Manager;


namespace Fun_Foodi.Controllers
{
    [Filter.AuthorizeUser]

    public class AddController : Controller
    {
        // GET: Add
        public ActionResult Index()
        {
            return View();
        }
       

        public ActionResult Salaryset()
        {
            return View();
        }
        [HttpGet]
        public ActionResult FoodItemType()
        {
            ViewBag.Message = "";
            return View();
        }
        [HttpPost]
        public ActionResult FoodItemType(FoodItemTypeModel Add)
        {
            FoodItemTypeManager obj = new FoodItemTypeManager();
            if (ModelState.IsValid)
            {
                int a = obj.Fooditemtype(Add);
                if (a > 0)
                {
                    ViewBag.Message = "Data Enter Successfully" + a;
                }
                else
                {
                    ViewBag.Message = "Data Enter not Successfully";
                }
            }
            return View();
        }


        [HttpGet]
        public ActionResult FoodItemName()
        {
            
            ViewBag.Message = "";
            return View();
        }
        [HttpPost]
        public ActionResult FoodItemName(FoodItemNameModel Add)
        {
            FoodItemNameManager obj = new FoodItemNameManager();
            if(ModelState.IsValid)
            {
                int a = obj.Fooditemname(Add);
                if (a > 0)
                {
                    ViewBag.Message = "Data Enter Successfully" + a;
                }
                else
                {
                    ViewBag.Message = "Data Enter not Successfully";
                }
            }
            return View();
        }
        public ActionResult ViewFood()
        {
            FoodItemNameManager obj = new FoodItemNameManager();
            List<FoodItemNameModel> List = obj.SelectAdd();
            return View(List);
        }












        [HttpGet]
        public ActionResult UpdateFoodItemName(int CstID)
        {
            //FunFoodiEntities2 PjE = new FunFoodiEntities2();
            //ViewBag.type = new SelectList(PjE.FITcategories, "TCID", "FoodTypeCategory");




            FoodItemNameManager obj = new FoodItemNameManager();

            FoodItemNameModel Add = obj.GetCust(CstID);
            if (Add == null)
            {
                ViewBag.Message = "Data not Found";
                return RedirectToAction("ViewFood");
            }
            else
            {
                ViewBag.Message = " ";
                return View(Add);
            }

        }
        [HttpPost]
        public ActionResult UpdateFoodItemName(FoodItemNameModel Cst)
        {
            if (ModelState.IsValid)
            {
                FoodItemNameManager obj = new FoodItemNameManager();

                bool check = obj.UpdatedCst(Cst);
                if (check)
                {
                    ViewBag.Message = "Data Update Successfully";
                    return RedirectToAction("ViewFood");
                }
                else
                {
                    return View();
                }
            }
            else
            {
                return View();
            }
           
        }
        public ActionResult DeleteCusotmer(int CstID)
        {
            FoodItemNameManager obj = new FoodItemNameManager();

            bool check = obj.DeleteCst(CstID);
            if (check)
            {
                ViewBag.Message = "Data Deleted Successfully";
            }
            else
            {
                ViewBag.Message = "Error";
            }
            return RedirectToAction("ViewFood");

        }


    }
}