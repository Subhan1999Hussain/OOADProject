﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using Fun_Foodi.Models;
using System.Data.Entity;

namespace Fun_Foodi.Manager
{
    public class BuyingProductManager : GeneralManager
    {
        public int BuyPro(BuyingProductModel order)
        {
            int ID = 0;
            using (FunFoodiEntities2 DB = new FunFoodiEntities2())
            {
                BuyingPro tbladd = new BuyingPro();
                tbladd.Address = order.Address;
                tbladd.Contact = order.contact;
                tbladd.EmailAddress = order.email;
                tbladd.ProductName = order.pname;
                tbladd.Quantity = order.Quantity;
                tbladd.Payment = order.payment;
                tbladd.Amount = order.Ramount;
                DB.BuyingProes.Add(tbladd);
                 
                    DB.SaveChanges();
                ID = tbladd.BPID;
            }
            return ID;
        }
        public List<BuyingProductModel> SelectAdd()
        {
            using (FunFoodiEntities2 DB = new FunFoodiEntities2())

            {
                var request = DB.BuyingProes.ToList();
                List<BuyingProductModel> List = request.Select(x => new BuyingProductModel { ID=x.BPID, Address = x.Address, contact = x.Contact, payment = x.Payment, Quantity = x.Quantity, pname = x.ProductName, email=x.EmailAddress,Ramount=x.Amount }).ToList();

                //List<AddCustomerModel> List = request.Select(x => new AddCustomerModel { Name = x.Name, address = x.Address, Contact = x.ContactNo, EmailAddress = x.EmailAddress }).ToString();//Name = x.Name, address = x.Address, Contact = x.ContactNo, EmailAddress = x.EmailAddress }).ToString();
                return List;
            }
        }
    }
}