﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using Fun_Foodi.Models;
using System.Data.Entity;

namespace Fun_Foodi.Manager
{
    public class AddOrderManager : GeneralManager
    {
        public int addorder(AddOrderModel order)
        {
            int ID = 0;
            using (FunFoodiEntities2 DB = new FunFoodiEntities2())
            {
                SaleFoodOrder tbladd = new SaleFoodOrder();

                tbladd.ItemName = order.FoodItemName;
                tbladd.ItemType = order.FoodItemType;
                tbladd.Price = order.Price;
                tbladd.Quantity = order.Quantity;
                tbladd.RefundAmount = order.RefundAmount;
                tbladd.TotalAmount = order.TotalAmount;
                tbladd.TotalCost = order.TotalCost;
                tbladd.CurrentTime = "12";
                tbladd.CurrentDate = "24";
                DB.SaleFoodOrders.Add(tbladd);
                DB.SaveChanges();
                ID = tbladd.SFOID;
            }
            return ID;
        }
        public List<AddOrderModel> SelectAdd()
        {
            using (FunFoodiEntities2 DB = new FunFoodiEntities2())

            {
                var request = DB.SaleFoodOrders.ToList();
                List<AddOrderModel> List = request.Select(x => new AddOrderModel {  TCID = x.SFOID, FoodItemType = x.ItemType, FoodItemName = x.ItemName, Price = x.Price, Quantity = x.Quantity, TotalAmount=x.Price, TotalCost=x.TotalAmount,RefundAmount=x.RefundAmount}).ToList();

                //List<AddCustomerModel> List = request.Select(x => new AddCustomerModel { Name = x.Name, address = x.Address, Contact = x.ContactNo, EmailAddress = x.EmailAddress }).ToString();//Name = x.Name, address = x.Address, Contact = x.ContactNo, EmailAddress = x.EmailAddress }).ToString();
                return List;
            }
        }
    }
}