﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using Fun_Foodi.Models;
using System.Data.Entity;

namespace Fun_Foodi.Manager
{
    public class NewEmployeeManager : GeneralManager
    {
        public int NewEmployee(NewEmployeeModel Add)
        {
            int ID = 0;
            using (FunFoodiEntities2 DB = new FunFoodiEntities2())
            {
                NewEmployee tbladd = new NewEmployee();
                
                tbladd.FirstName = Add.FirstName;
                tbladd.LastName = Add.LastName;
                tbladd.Password = Add.Password;
                tbladd.Salary = Convert.ToInt32(Add.Salary);
                tbladd.EmailAddress = Add.EmailAddress;
                tbladd.Address = Add.Address;
                tbladd.Contact = Add.Contact;
                tbladd.Bio = Add.Bio;
                tbladd.CurrentTime = "12";
                tbladd.CurrentDate = "24";
                DB.NewEmployees.Add(tbladd);           
                DB.SaveChanges();
                ID = tbladd.NEID;
            }
            return ID;
        }
        public List<NewEmployeeModel> SelectAdd()
        {
            using (FunFoodiEntities2 DB = new FunFoodiEntities2())

            {
                var request = DB.NewEmployees.ToList();
                List<NewEmployeeModel> List = request.Select(x => new NewEmployeeModel { Address=x.Address, Bio=x.Bio, Contact=x.Contact, EmailAddress=x.EmailAddress, FirstName=x.FirstName, LastName=x.LastName, Password=x.Password, Salary=x.Salary }).ToList();

                //List<AddCustomerModel> List = request.Select(x => new AddCustomerModel { Name = x.Name, address = x.Address, Contact = x.ContactNo, EmailAddress = x.EmailAddress }).ToString();//Name = x.Name, address = x.Address, Contact = x.ContactNo, EmailAddress = x.EmailAddress }).ToString();
                return List;
            }
        }

        public NewEmployeeModel GetCust(int CusID)
        {
            using (FunFoodiEntities2 DB = new FunFoodiEntities2())
            {
                var Request = DB.NewEmployees.Where(x => x.NEID == CusID).FirstOrDefault();
                NewEmployeeModel Customer = null;
                if (Request != null)
                {
                    Customer = new NewEmployeeModel()
                    {
                        NEID = Request.NEID,
                        FirstName=Request.FirstName,
                        LastName=Request.LastName,
                        Address=Request.Address,
                        EmailAddress=Request.EmailAddress,
                        Bio=Request.Bio,
                        Contact=Request.Contact,
                        Password=Request.Password,
                        Salary=Request.Salary
                       


                    };
                    return Customer;

                }
                else
                {
                    return Customer;
                }

            }
        }
        public bool UpdatedCst(NewEmployeeModel cst)
        {
            using (FunFoodiEntities2 DB = new FunFoodiEntities2())
            {
                int foodid = 0;
                var Data = DB.NewEmployees.Where(x => x.NEID == cst.NEID).FirstOrDefault();
                if (Data != null)
                {
                    Data.FirstName = cst.FirstName;
                    Data.LastName = cst.LastName;
                    Data.Password = cst.Password;
                    Data.Salary = cst.Salary;
                    Data.Contact = cst.Contact;
                    Data.Bio = cst.Bio;
                    Data.Address = cst.Address;
                    Data.CurrentDate = "12";
                    Data.CurrentTime = "1234";
                    Data.EmailAddress = cst.EmailAddress;
                    DB.Entry(Data).State = EntityState.Modified;//update ki Query chaly ge is stament ki waja defalut
                    DB.SaveChanges();
                    foodid = Data.NEID;
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }

        public bool DeleteCst(int cst)
        {
            using (FunFoodiEntities2 DB = new FunFoodiEntities2())
            {
                var Data = DB.NewEmployees.Where(x => x.NEID == cst).FirstOrDefault();
                if (Data != null)
                {
                    DB.Entry(Data).State = EntityState.Deleted;//update ki Query chaly ge is stament ki waja defalut
                    DB.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

    }
}