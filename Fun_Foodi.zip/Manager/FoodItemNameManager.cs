﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using Fun_Foodi.Models;
using System.Data.Entity;
namespace Fun_Foodi.Manager
{
    public class FoodItemNameManager : GeneralManager
    {
        public int Fooditemname(FoodItemNameModel Add)
        {
            int ID = 0;
            using (FunFoodiEntities2 DB = new FunFoodiEntities2())
            {
                FIName tbladd = new FIName();
                tbladd.FoodItemName = Add.FoodItemName;
                tbladd.FoodTypeCategory = Add.FoodItemType;
                tbladd.Price = Add.Price;
                tbladd.Quantity = Add.Quantity;
                DB.FINames.Add(tbladd);
                DB.SaveChanges();
                ID = tbladd.NID;
            }
            return ID;
        }
        public List<FoodItemNameModel> SelectAdd()
        {
            using (FunFoodiEntities2 DB = new FunFoodiEntities2())

            {
                var request = DB.FINames.ToList();
                List<FoodItemNameModel> List = request.Select(x => new FoodItemNameModel { NID=x.NID ,FoodItemType = x.FoodTypeCategory,FoodItemName=x.FoodItemName, Price=x.Price,Quantity=x.Quantity}).ToList();

                //List<AddCustomerModel> List = request.Select(x => new AddCustomerModel { Name = x.Name, address = x.Address, Contact = x.ContactNo, EmailAddress = x.EmailAddress }).ToString();//Name = x.Name, address = x.Address, Contact = x.ContactNo, EmailAddress = x.EmailAddress }).ToString();
                return List;
            }
        }
        public FoodItemNameModel GetCust(int CusID)
        {
            using (FunFoodiEntities2 DB = new FunFoodiEntities2())
            {
                var Request = DB.FINames.Where(x => x.NID == CusID).FirstOrDefault();
                FoodItemNameModel Customer = null;
                if (Request != null)
                {
                    Customer = new FoodItemNameModel()
                    {
                        NID=Request.NID,
                        FoodItemName=Request.FoodItemName,
                        Price=Request.Price,
                        Quantity=Request.Quantity
                       

                    };
                    return Customer;

                }
                else
                {
                    return Customer;
                }

            }
        }
        public bool UpdatedCst(FoodItemNameModel cst)
        {
            using (FunFoodiEntities2 DB = new FunFoodiEntities2())
            {
                var Data = DB.FINames.Where(x => x.NID == cst.NID).FirstOrDefault();
                if (Data != null)
                {
                    Data.FoodItemName = cst.FoodItemName;
                    Data.Price = cst.Price;
                    Data.Quantity = cst.Quantity;
                    DB.Entry(Data).State = EntityState.Modified;//update ki Query chaly ge is stament ki waja defalut
                    DB.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }

        public bool DeleteCst(int cst)
        {
            using (FunFoodiEntities2 DB = new FunFoodiEntities2())
            {
                var Data = DB.FINames.Where(x => x.NID==cst).FirstOrDefault();
                if (Data != null)
                {
                    DB.Entry(Data).State = EntityState.Deleted;//update ki Query chaly ge is stament ki waja defalut
                    DB.SaveChanges();
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
    }
}