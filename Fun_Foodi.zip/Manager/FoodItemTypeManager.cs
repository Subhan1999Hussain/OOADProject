﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using Fun_Foodi.Models;
using System.Data.Entity;

namespace Fun_Foodi.Manager
{
    public class FoodItemTypeManager : GeneralManager
    {
        public int Fooditemtype(FoodItemTypeModel Add)
        {
            int ID = 0;
            using (FunFoodiEntities2 DB = new FunFoodiEntities2())
            {
                FITcategory tbladd = new FITcategory();
                tbladd.FoodTypeCategory = Add.FoodItemType;
                DB.FITcategories.Add(tbladd);
                DB.SaveChanges();
                ID = tbladd.TCID;

            }
            return ID;
        }
       

    }
}