﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace Fun_Foodi.Manager
{
    
    public class GeneralManager
    {
        public static string Constring = @"Data Source=(local);Initial Catalog=FunFoodi;Integrated Security=True";
        public static SqlConnection Con = new SqlConnection(Constring);
    }
}