﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace Fun_Foodi.Models
{
    public class FoodItemNameModel
    {

        public int NID { get; set; }
        public int TCID { get; set; }

        public string FoodItemType { get; set; }

        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public string FoodItemName { get; set; }

        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public int Quantity { get; set; }

        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public int Price { get; set; }
       

    }
}