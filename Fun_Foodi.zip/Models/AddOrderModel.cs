﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace Fun_Foodi.Models
{
    public class AddOrderModel
    {
        public int NID { get; set; }
        public int TCID { get; set; }
        
        public string FoodItemType { get; set; }

        
        public string FoodItemName { get; set; }

        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public int Quantity { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public int Price { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public int TotalCost { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public int TotalAmount { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public int RefundAmount { get; set; }

    }
}