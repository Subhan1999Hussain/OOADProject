﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;


namespace Fun_Foodi.Models
{
    public class NewEmployeeModel
    {
        public int NEID { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public string FirstName { get; set; }

         [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public string Password { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public string Bio { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public string EmailAddress { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public int? Salary { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public string Address { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public string Contact { get; set; }
        

    }
}