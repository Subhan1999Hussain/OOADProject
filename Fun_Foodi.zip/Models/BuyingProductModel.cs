﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace Fun_Foodi.Models
{
    public class BuyingProductModel
    {
        public int ID { get; set; }

        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public string pname { get; set; }

        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public string Address { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public string Quantity { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public string email { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public string contact { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public string Ramount { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public string payment { get; set; }
        [Required(ErrorMessage = "Food Item Name is important to submit this form")]
        public string receiving { get; set; }
       
    }
}